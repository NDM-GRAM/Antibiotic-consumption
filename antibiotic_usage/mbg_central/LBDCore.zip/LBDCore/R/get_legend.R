#' @rdname g_legend
#'
#' @export
get_legend <- function(a.gplot) {
  g_legend(a.gplot)
}
