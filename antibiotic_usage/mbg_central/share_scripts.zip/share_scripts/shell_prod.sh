#!/bin/sh
/usr/local/codem/public_use_anaconda/bin/R <$1 --no-save $@
