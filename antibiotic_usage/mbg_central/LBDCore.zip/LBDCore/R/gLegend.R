#' @rdname g_legend
#' @export
gLegend <- function(a.gplot) {
  g_legend(a.gplot)
}
